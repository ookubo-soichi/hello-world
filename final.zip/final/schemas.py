from datetime import date
from pydantic import BaseModel

class Record(BaseModel):
    id: int
    date: date
    height: float
    picture_url: str
    array: list
    class Config:
        orm_mode = True
