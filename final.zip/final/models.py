from sqlalchemy import Column, Integer, Float, String, JSON, ForeignKey
from sqlalchemy.types import Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy_imageattach.entity import Image, image_attachment
from database import Base


class Record(Base):
    __tablename__ = "Record"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date)
    height = Column(Float)
    picture = image_attachment('Picture')
    picture_url = Column(String(255))
    array= Column(JSON)
    
class Picture(Base, Image):
    __tablename__ = 'Picture'
    record_id = Column(Integer, ForeignKey('Record.id'), primary_key=True)
    record = relationship('Record')
