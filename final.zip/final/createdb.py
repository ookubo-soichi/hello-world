import os, csv, datetime
import pandas as pd
from sqlalchemy_imageattach.stores.fs import FileSystemStore
from sqlalchemy_imageattach.stores.fs import HttpExposedFileSystemStore
from sqlalchemy_imageattach.context import store_context
import models
from database import SessionLocal, engine

db = SessionLocal()

models.Base.metadata.create_all(bind=engine)
store = FileSystemStore(path=os.getcwd()+'/images/', base_url = '/')

df = pd.read_csv('./sample.csv')
for i, row in df.iterrows():
    db_record = models.Record(
        date=datetime.datetime.strptime(row["date"], "%Y/%m/%d"),
        height=row["height"],
        array=[1,2,3])
    db.add(db_record)
db.commit()

db_records = db.query(models.Record).all()
for i, db_record in enumerate(db_records):
    with store_context(store):
        with open('./sample.png', 'rb') as f_img:
            db_record.picture.from_file(f_img)
            db.commit()

db_records = db.query(models.Record).all()
for db_record in db_records:
    with store_context(store):
        db_record.picture_url = db_record.picture.locate()
db.commit()

db.close()
