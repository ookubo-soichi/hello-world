import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import requests
import plotly.figure_factory as ff
import plotly.graph_objects as go
import plotly.express as px
from PIL import Image
import base64

st.title('My app')

server_url = 'http://127.0.0.1:8000'+'/records/'
r = requests.get(server_url, params={})
df = pd.json_normalize(r.json())

st.dataframe(df, height=100)

option = st.sidebar.selectbox('Date', sorted(df['date']))

idx = df[df['date'] == option].index

for i in idx:
     #image = Image.open('./images/'+df.iloc[i]['picture_url'].split('?')[0])
     #st.image(image, caption=option+'_'+str(i))
     image = open('./images/'+df.iloc[i]['picture_url'].split('?')[0], 'rb')
     contents = image.read()
     data_url = base64.b64encode(contents).decode("utf-8")
     image.close()
     st.markdown(
          f'<img src="data:image/gif;base64,{data_url}" alt="image" width=400>',
          unsafe_allow_html=True,
     )
